# ============================================================
# CREDIT RISK MODELING
# 9.4 BACKTESTING | 9.5 MODEL STABILITY | 9.6 BENCHMARKING
# ============================================================
# INPUT FILE:
# C:\Users\rajat\OneDrive\Desktop\Credit Risk\Inputs & code\credit_risk_data_500_observations.csv
#
# This script is designed to run in one click.
# It reads the supplied 500-observation credit-risk dataset,
# builds a Champion and Challenger model, and performs:
#   9.4 Backtesting
#   9.5 Model Stability: PSI + CSI + Population Drift
#   9.6 Benchmarking: Benchmark vs Champion vs Challenger
#
# IMPORTANT DATA LIMITATION:
# The supplied file contains no date/time variable. Therefore,
# true calendar-period backtesting cannot be performed.
# For demonstration, observations are ordered into four sequential
# pseudo-periods. Treat this as an educational backtesting framework,
# not as evidence of actual calendar-time model performance.
# ============================================================


# ============================================================
# 9.0 SETTINGS
# ============================================================

import warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from scipy.stats import binomtest
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    roc_auc_score,
    roc_curve,
    accuracy_score,
    precision_score,
    recall_score,
    confusion_matrix
)

FILE_PATH = r"C:\Users\rajat\OneDrive\Desktop\Credit Risk\Inputs & code\credit_risk_data_500_observations.csv"

TARGET = "default_flag"
ID_COL = "customer_id"

RANDOM_STATE = 42
TEST_SIZE = 0.30

EPS = 0.0001

print("=" * 80)
print("CREDIT RISK MODELING: 9.4 BACKTESTING | 9.5 STABILITY | 9.6 BENCHMARKING")
print("=" * 80)


# ============================================================
# 9.1 IMPORT AND READ DATA
# ============================================================

try:
    df = pd.read_csv(FILE_PATH)
except FileNotFoundError:
    # This fallback allows the script to work when the uploaded
    # file has a different local name but is in the same folder.
    fallback = r"C:\Users\rajat\OneDrive\Desktop\Credit Risk\Inputs & code"
    candidates = list(Path(fallback).glob("credit_risk_data_500_observations*.csv"))

    if not candidates:
        raise FileNotFoundError(
            "CSV file not found. Please check FILE_PATH at the top of the script."
        )

    print(f"\nExact file path not found. Using: {candidates[0]}")
    df = pd.read_csv(candidates[0])

print("\n1. DATASET")
print("-" * 80)
print("Rows:", df.shape[0])
print("Columns:", df.shape[1])
print("\nColumns:")
print(df.columns.tolist())


# ============================================================
# 9.2 DATA QUALITY CHECK
# ============================================================

print("\n2. DATA QUALITY CHECK")
print("-" * 80)

print("\nMissing values:")
print(df.isnull().sum())

print("\nDefault distribution:")
print(df[TARGET].value_counts())
print("\nDefault rate:", round(df[TARGET].mean() * 100, 2), "%")


# ============================================================
# 9.3 DEFINE MODEL VARIABLES
# ============================================================

features = [
    "age",
    "annual_income",
    "employment_years",
    "loan_amount",
    "credit_score",
    "debt_to_income",
    "num_open_accounts",
    "delinquencies_2yr",
    "utilization_ratio"
]

missing_features = [c for c in features + [TARGET] if c not in df.columns]

if missing_features:
    raise ValueError(
        f"The following required columns are missing: {missing_features}"
    )

X = df[features].copy()
y = df[TARGET].astype(int).copy()

print("\n3. MODEL VARIABLES")
print("-" * 80)
print("Features:")
for c in features:
    print(" -", c)

print("\nTarget:", TARGET)


# ============================================================
# 9.4 TRAIN / TEST SPLIT
# ============================================================

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=TEST_SIZE,
    random_state=RANDOM_STATE,
    stratify=y
)

print("\n4. TRAIN / TEST SPLIT")
print("-" * 80)
print("Training observations:", len(X_train))
print("Testing observations :", len(X_test))


# ============================================================
# 9.5 BUILD CHAMPION MODEL
# ============================================================
# Champion = Logistic Regression
# This is a transparent and common benchmark for credit risk.

champion = Pipeline([
    ("imputer", SimpleImputer(strategy="median")),
    ("scaler", StandardScaler()),
    ("model", LogisticRegression(
        max_iter=2000,
        random_state=RANDOM_STATE
    ))
])

champion.fit(X_train, y_train)

champion_pd = champion.predict_proba(X_test)[:, 1]
champion_pred = (champion_pd >= 0.50).astype(int)

champion_auc = roc_auc_score(y_test, champion_pd)

print("\n5. CHAMPION MODEL")
print("-" * 80)
print("Model: Logistic Regression")
print("Champion AUC:", round(champion_auc, 4))


# ============================================================
# 9.6 BUILD CHALLENGER MODEL
# ============================================================
# Challenger = Random Forest
# It represents a different modelling methodology.

challenger = Pipeline([
    ("imputer", SimpleImputer(strategy="median")),
    ("model", RandomForestClassifier(
        n_estimators=300,
        max_depth=5,
        min_samples_leaf=8,
        random_state=RANDOM_STATE,
        class_weight="balanced"
    ))
])

challenger.fit(X_train, y_train)

challenger_pd = challenger.predict_proba(X_test)[:, 1]
challenger_pred = (challenger_pd >= 0.50).astype(int)

challenger_auc = roc_auc_score(y_test, challenger_pd)

print("\n6. CHALLENGER MODEL")
print("-" * 80)
print("Model: Random Forest")
print("Challenger AUC:", round(challenger_auc, 4))


# ============================================================
# 9.4 BACKTESTING
# ============================================================
# The source file has no date variable.
# We therefore create four sequential pseudo-periods based on
# the existing row order ONLY for educational demonstration.

print("\n" + "=" * 80)
print("9.4 BACKTESTING")
print("=" * 80)


# ------------------------------------------------------------
# 9.4.1 CREATE PSEUDO-PERIODS
# ------------------------------------------------------------

backtest_df = df.copy().reset_index(drop=True)

backtest_df["pseudo_period"] = pd.qcut(
    np.arange(len(backtest_df)),
    q=4,
    labels=["Period 1", "Period 2", "Period 3", "Period 4"]
)

# Score all observations using the Champion
backtest_df["predicted_pd"] = champion.predict_proba(
    backtest_df[features]
)[:, 1]

backtest_summary = (
    backtest_df
    .groupby("pseudo_period", observed=True)
    .agg(
        observations=(TARGET, "size"),
        actual_defaults=(TARGET, "sum"),
        actual_default_rate=(TARGET, "mean"),
        predicted_pd=("predicted_pd", "mean")
    )
    .reset_index()
)

backtest_summary["forecast_error"] = (
    backtest_summary["actual_default_rate"]
    - backtest_summary["predicted_pd"]
)

backtest_summary["absolute_error"] = (
    backtest_summary["forecast_error"].abs()
)

backtest_summary["error_pp"] = (
    backtest_summary["forecast_error"] * 100
)

print("\n7. FORECAST VS ACTUAL DEFAULTS")
print("-" * 80)
print(backtest_summary.to_string(index=False))


# ------------------------------------------------------------
# 9.4.2 OVERALL FORECAST ERROR
# ------------------------------------------------------------

overall_actual = backtest_df[TARGET].mean()
overall_predicted = backtest_df["predicted_pd"].mean()

overall_error = overall_actual - overall_predicted

print("\n8. OVERALL BACKTEST RESULT")
print("-" * 80)
print("Actual default rate    :", round(overall_actual, 4))
print("Predicted default rate :", round(overall_predicted, 4))
print("Forecast error         :", round(overall_error, 4))
print("Forecast error (pp)    :", round(overall_error * 100, 2), "percentage points")


# ------------------------------------------------------------
# 9.4.3 STATISTICAL TEST
# ------------------------------------------------------------
# Test whether the observed number of defaults is consistent
# with the aggregate predicted probability.
#
# H0: observed default rate is consistent with model PD.
# This is a simple binomial diagnostic, not a complete
# model-validation test.

n_obs = len(backtest_df)
observed_defaults = int(backtest_df[TARGET].sum())
expected_pd = float(backtest_df["predicted_pd"].mean())

binom_result = binomtest(
    observed_defaults,
    n=n_obs,
    p=min(max(expected_pd, EPS), 1 - EPS),
    alternative="two-sided"
)

print("\n9. STATISTICAL BACKTEST TEST")
print("-" * 80)
print("Observed defaults :", observed_defaults)
print("Observations      :", n_obs)
print("Expected PD       :", round(expected_pd, 4))
print("Binomial p-value  :", round(binom_result.pvalue, 4))

if binom_result.pvalue < 0.05:
    print("Interpretation     : Statistical evidence of a difference at 5%.")
else:
    print("Interpretation     : No statistically significant difference at 5%.")


# ------------------------------------------------------------
# 9.4.4 BACKTEST CHART
# ------------------------------------------------------------

plt.figure(figsize=(10, 5))

x = np.arange(len(backtest_summary))
width = 0.35

plt.bar(
    x - width / 2,
    backtest_summary["actual_default_rate"],
    width,
    label="Actual Default Rate"
)

plt.bar(
    x + width / 2,
    backtest_summary["predicted_pd"],
    width,
    label="Predicted PD"
)

plt.xticks(x, backtest_summary["pseudo_period"])
plt.ylabel("Default Rate / PD")
plt.title("9.4 Backtesting: Forecast vs Actual Defaults")
plt.legend()
plt.tight_layout()
plt.show()


# ============================================================
# 9.5 MODEL STABILITY
# ============================================================

print("\n" + "=" * 80)
print("9.5 MODEL STABILITY")
print("=" * 80)


# ------------------------------------------------------------
# 9.5.1 POPULATION DRIFT
# ------------------------------------------------------------
# Reference = first half
# Current   = second half
#
# Because no date exists, this is sequential-sample drift,
# not true calendar-time drift.

midpoint = len(df) // 2

reference = df.iloc[:midpoint].copy()
current = df.iloc[midpoint:].copy()

print("\n10. REFERENCE VS CURRENT POPULATION")
print("-" * 80)
print("Reference observations:", len(reference))
print("Current observations  :", len(current))


# ------------------------------------------------------------
# 9.5.2 PSI FUNCTION
# ------------------------------------------------------------

def calculate_psi(reference_series, current_series, bins=10):
    """
    Population Stability Index.

    PSI = SUM[(Current % - Reference %) *
              ln(Current % / Reference %)]
    """

    ref = pd.Series(reference_series).dropna()
    cur = pd.Series(current_series).dropna()

    # Numeric variables:
    # create bins using reference population.
    if pd.api.types.is_numeric_dtype(ref):

        try:
            cut_points = np.unique(
                np.nanquantile(
                    ref,
                    np.linspace(0, 1, bins + 1)
                )
            )

            if len(cut_points) < 3:
                return np.nan

            ref_bins = pd.cut(
                ref,
                bins=cut_points,
                include_lowest=True,
                duplicates="drop"
            )

            cur_bins = pd.cut(
                cur,
                bins=cut_points,
                include_lowest=True,
                duplicates="drop"
            )

        except Exception:
            return np.nan

    else:
        ref_bins = ref.astype(str)
        cur_bins = cur.astype(str)

    ref_dist = ref_bins.value_counts(normalize=True, sort=False)
    cur_dist = cur_bins.value_counts(normalize=True, sort=False)

    all_bins = ref_dist.index.union(cur_dist.index)

    ref_dist = ref_dist.reindex(all_bins, fill_value=0)
    cur_dist = cur_dist.reindex(all_bins, fill_value=0)

    ref_dist = ref_dist.replace(0, EPS)
    cur_dist = cur_dist.replace(0, EPS)

    psi_components = (
        (cur_dist - ref_dist)
        * np.log(cur_dist / ref_dist)
    )

    return float(psi_components.sum())


# ------------------------------------------------------------
# 9.5.3 PSI FOR OVERALL POPULATION
# ------------------------------------------------------------

# We use predicted PD as the model-output distribution.
reference_pd = champion.predict_proba(reference[features])[:, 1]
current_pd = champion.predict_proba(current[features])[:, 1]

overall_psi = calculate_psi(reference_pd, current_pd)

print("\n11. MODEL OUTPUT PSI")
print("-" * 80)
print("PSI:", round(overall_psi, 4))

print("""
Important:
PSI thresholds are institution-specific.
A common educational convention is:
< 0.10  = relatively small movement
0.10-0.25 = moderate movement
> 0.25  = substantial movement

These are NOT universal regulatory thresholds.
""")


# ------------------------------------------------------------
# 9.5.4 CSI — CHARACTERISTIC STABILITY INDEX
# ------------------------------------------------------------
# CSI applies the same distribution-shift logic to individual
# characteristics/variables.

csi_results = []

for feature in features:
    value = calculate_psi(
        reference[feature],
        current[feature]
    )

    csi_results.append({
        "variable": feature,
        "CSI": value
    })

csi_df = pd.DataFrame(csi_results).sort_values(
    "CSI",
    ascending=False
)

print("\n12. CHARACTERISTIC STABILITY INDEX — CSI")
print("-" * 80)
print(csi_df.to_string(index=False))


# ------------------------------------------------------------
# 9.5.5 CSI CHART
# ------------------------------------------------------------

plt.figure(figsize=(10, 5))

plt.bar(
    csi_df["variable"],
    csi_df["CSI"]
)

plt.axhline(
    0.10,
    linestyle="--",
    label="Illustrative 0.10 reference"
)

plt.xticks(rotation=45, ha="right")
plt.ylabel("CSI")
plt.title("9.5 CSI — Characteristic Stability by Variable")
plt.legend()
plt.tight_layout()
plt.show()


# ------------------------------------------------------------
# 9.5.6 DEFAULT-RATE STABILITY
# ------------------------------------------------------------

reference_default_rate = reference[TARGET].mean()
current_default_rate = current[TARGET].mean()

print("\n13. DEFAULT-RATE STABILITY")
print("-" * 80)
print("Reference default rate:", round(reference_default_rate, 4))
print("Current default rate  :", round(current_default_rate, 4))
print(
    "Change (pp):",
    round((current_default_rate - reference_default_rate) * 100, 2)
)


# ------------------------------------------------------------
# 9.5.7 MODEL PERFORMANCE STABILITY
# ------------------------------------------------------------

def safe_auc(actual, predicted):
    if len(np.unique(actual)) < 2:
        return np.nan
    return roc_auc_score(actual, predicted)


reference_auc = safe_auc(
    reference[TARGET],
    reference_pd
)

current_auc = safe_auc(
    current[TARGET],
    current_pd
)

print("\n14. AUC STABILITY")
print("-" * 80)
print("Reference AUC:", round(reference_auc, 4))
print("Current AUC  :", round(current_auc, 4))

if pd.notna(reference_auc) and pd.notna(current_auc):
    print(
        "AUC change   :",
        round(current_auc - reference_auc, 4)
    )


# ------------------------------------------------------------
# 9.5.8 STABILITY SUMMARY
# ------------------------------------------------------------

print("\n15. MODEL STABILITY SUMMARY")
print("-" * 80)

print("Overall PSI:", round(overall_psi, 4))
print("Largest CSI:")
print(csi_df.head(5).to_string(index=False))

print("""
Stability should be investigated through three lenses:
1. Population movement
2. Characteristic movement
3. Outcome / performance movement

A high PSI or CSI does not by itself prove model deterioration.
It identifies an area requiring investigation.
""")


# ============================================================
# 9.6 MODEL BENCHMARKING
# ============================================================

print("\n" + "=" * 80)
print("9.6 MODEL BENCHMARKING")
print("=" * 80)


# ------------------------------------------------------------
# 9.6.1 SIMPLE BENCHMARK MODEL
# ------------------------------------------------------------
# Benchmark = historical average default rate.
# This is deliberately simple: it provides a baseline against
# which predictive models can demonstrate incremental value.

benchmark_pd = np.repeat(
    y_train.mean(),
    len(y_test)
)

benchmark_auc = roc_auc_score(
    y_test,
    benchmark_pd
) if len(np.unique(benchmark_pd)) > 1 else np.nan

print("\n16. BENCHMARK MODEL")
print("-" * 80)
print("Benchmark: training-sample average default rate")
print("Benchmark PD:", round(y_train.mean(), 4))
print("Benchmark AUC: not meaningful for constant predictions")


# ------------------------------------------------------------
# 9.6.2 GINI FUNCTION
# ------------------------------------------------------------

def gini_from_auc(auc):
    return 2 * auc - 1


# ------------------------------------------------------------
# 9.6.3 KS FUNCTION
# ------------------------------------------------------------

def calculate_ks(y_true, predicted_pd):

    temp = pd.DataFrame({
        "actual": y_true,
        "pd": predicted_pd
    }).sort_values(
        "pd",
        ascending=False
    )

    total_bad = temp["actual"].sum()
    total_good = len(temp) - total_bad

    if total_bad == 0 or total_good == 0:
        return np.nan

    temp["cum_bad"] = temp["actual"].cumsum() / total_bad
    temp["cum_good"] = (
        (1 - temp["actual"]).cumsum() / total_good
    )

    ks = np.max(
        np.abs(
            temp["cum_bad"] -
            temp["cum_good"]
        )
    )

    return float(ks)


champion_ks = calculate_ks(
    y_test,
    champion_pd
)

challenger_ks = calculate_ks(
    y_test,
    challenger_pd
)

champion_gini = gini_from_auc(champion_auc)
challenger_gini = gini_from_auc(challenger_auc)


# ------------------------------------------------------------
# 9.6.4 MODEL COMPARISON TABLE
# ------------------------------------------------------------

comparison = pd.DataFrame({
    "Model": [
        "Benchmark",
        "Champion - Logistic Regression",
        "Challenger - Random Forest"
    ],
    "AUC": [
        np.nan,
        champion_auc,
        challenger_auc
    ],
    "KS": [
        np.nan,
        champion_ks,
        challenger_ks
    ],
    "Gini": [
        np.nan,
        champion_gini,
        challenger_gini
    ],
    "Mean PD": [
        benchmark_pd.mean(),
        champion_pd.mean(),
        challenger_pd.mean()
    ]
})

print("\n17. BENCHMARK VS CHAMPION VS CHALLENGER")
print("-" * 80)
print(comparison.round(4).to_string(index=False))


# ------------------------------------------------------------
# 9.6.5 ROC CURVE
# ------------------------------------------------------------

fpr_c, tpr_c, _ = roc_curve(y_test, champion_pd)
fpr_ch, tpr_ch, _ = roc_curve(y_test, challenger_pd)

plt.figure(figsize=(8, 6))

plt.plot(
    fpr_c,
    tpr_c,
    label=f"Champion AUC = {champion_auc:.3f}"
)

plt.plot(
    fpr_ch,
    tpr_ch,
    label=f"Challenger AUC = {challenger_auc:.3f}"
)

plt.plot(
    [0, 1],
    [0, 1],
    linestyle="--",
    label="Random"
)

plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.title("9.6 Benchmarking: Champion vs Challenger ROC")
plt.legend()
plt.tight_layout()
plt.show()


# ------------------------------------------------------------
# 9.6.6 INCREMENTAL VALUE
# ------------------------------------------------------------

auc_difference = challenger_auc - champion_auc
ks_difference = challenger_ks - champion_ks

print("\n18. CHALLENGER INCREMENTAL VALUE")
print("-" * 80)
print("AUC improvement:", round(auc_difference, 4))
print("KS improvement :", round(ks_difference, 4))

if auc_difference > 0:
    print("The Challenger has higher AUC on this test sample.")
else:
    print("The Challenger does not have higher AUC on this test sample.")

if ks_difference > 0:
    print("The Challenger has higher KS on this test sample.")
else:
    print("The Challenger does not have higher KS on this test sample.")


# ============================================================
# 9.6.7 MODEL DECISION MATRIX
# ============================================================

decision_matrix = pd.DataFrame({
    "Dimension": [
        "Discrimination",
        "Calibration",
        "Stability",
        "Explainability",
        "Operational Complexity",
        "Governance"
    ],
    "Champion": [
        "Measured",
        "Measured separately",
        "Measured",
        "High",
        "Established",
        "Established"
    ],
    "Challenger": [
        "Measured",
        "Measured separately",
        "Requires monitoring",
        "Potentially lower",
        "Potentially higher",
        "Requires review"
    ]
})

print("\n19. CHAMPION VS CHALLENGER DECISION FRAMEWORK")
print("-" * 80)
print(decision_matrix.to_string(index=False))


# ============================================================
# 9.6.8 FEATURE IMPORTANCE — CHALLENGER
# ============================================================

rf_model = challenger.named_steps["model"]

importance_df = pd.DataFrame({
    "variable": features,
    "importance": rf_model.feature_importances_
}).sort_values(
    "importance",
    ascending=False
)

print("\n20. CHALLENGER VARIABLE IMPORTANCE")
print("-" * 80)
print(importance_df.to_string(index=False))

plt.figure(figsize=(9, 5))

plt.barh(
    importance_df["variable"],
    importance_df["importance"]
)

plt.gca().invert_yaxis()
plt.xlabel("Importance")
plt.title("9.6 Challenger Model — Variable Importance")
plt.tight_layout()
plt.show()


# ============================================================
# 21. FINAL CONSOLIDATED SUMMARY
# ============================================================

print("\n" + "=" * 80)
print("FINAL SUMMARY — 9.4 / 9.5 / 9.6")
print("=" * 80)

print("""
9.4 BACKTESTING
---------------
• Forecast default rates were compared with realised defaults.
• Forecast error was calculated by pseudo-period.
• A simple binomial statistical test was performed.
• IMPORTANT: no date variable exists in the supplied file, so
  the four periods are sequential pseudo-periods rather than
  genuine calendar-time backtesting.

9.5 MODEL STABILITY
-------------------
• PSI measured movement in model-output distribution.
• CSI measured movement in individual characteristics.
• Population default-rate movement was measured.
• AUC stability was compared between reference and current samples.
• PSI/CSI identify movement; they do not automatically prove
  model deterioration.

9.6 MODEL BENCHMARKING
----------------------
• A simple average-default-rate benchmark was established.
• Logistic Regression was treated as the Champion.
• Random Forest was treated as the Challenger.
• AUC, KS and Gini were compared.
• ROC curves and Challenger variable importance were displayed.
• A Challenger should not be selected using one metric alone.

KEY IDEA
--------
Backtesting asks:
"Are predicted outcomes consistent with realised outcomes?"

Model Stability asks:
"Has the population, model output or performance changed over time?"

Benchmarking asks:
"How does the current model compare with credible alternatives?"

Challenger Testing asks:
"Can an alternative model provide sufficient incremental value
under comparable business, operational and governance conditions?"
""")

print("=" * 80)
print("SCRIPT COMPLETED")
print("=" * 80)
